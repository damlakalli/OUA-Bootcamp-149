package com.example.hesap_makinesi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
